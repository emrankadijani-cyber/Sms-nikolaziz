package ir.niko.sms.ui

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ir.niko.sms.data.AppDb
import ir.niko.sms.data.ContactIO
import ir.niko.sms.data.SmsLog
import ir.niko.sms.data.St
import ir.niko.sms.util.Csv
import ir.niko.sms.util.Jalali
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LogRow(val head: TextView, val status: TextView, val body: TextView)

class ReportsFragment : Fragment() {
    private lateinit var db: AppDb
    private lateinit var adapter: RowAdapter<SmsLog, LogRow>
    private lateinit var summary: TextView
    private var slot = -1
    private var collectJob: Job? = null

    private val createDoc = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) export(uri)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View {
        val ctx = requireContext()
        db = AppDb.get(ctx)
        val root = ctx.vbox(8)

        val r = ctx.hbox()
        val spinner = Spinner(ctx)
        spinner.adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, listOf("همه خطوط", "سیم ۱", "سیم ۲"))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { slot = pos - 1; collect() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        r.add(spinner, 0, -2, 1f)
        r.add(ctx.btn("خروجی CSV", true) { createDoc.launch("niko-sms-report.csv") }, 0, -2, 1f)
        root.addView(r)

        summary = ctx.tv("", 12f, false, C.GRAY)
        root.addView(summary)

        adapter = RowAdapter<SmsLog, LogRow>({ c ->
            val col = c.vbox(8)
            val h = c.tv("", 14f, true)
            val s = c.tv("", 12f, true)
            val b = c.tv("", 12f, false, C.GRAY)
            col.addView(h); col.addView(s); col.addView(b)
            Pair<View, LogRow>(col, LogRow(h, s, b))
        }, { h, l ->
            h.head.text = "${l.name} — ${l.phone}"
            h.status.text = St.fa(l.status) + if (l.error.isNotEmpty()) " (${l.error})" else ""
            h.status.setTextColor(
                when (l.status) {
                    St.FAILED -> C.RED
                    St.SENT, St.DELIVERED -> C.GREEN
                    else -> C.ORANGE
                }
            )
            h.body.text = "${l.simLabel} | ${Jalali.format(l.createdAt)}\n${l.text.take(80)}"
        })
        val rv = RecyclerView(ctx)
        rv.layoutManager = LinearLayoutManager(ctx)
        rv.adapter = adapter
        root.add(rv, -1, 0, 1f)
        return root
    }

    private fun collect() {
        collectJob?.cancel()
        collectJob = viewLifecycleOwner.lifecycleScope.launch {
            db.logs().observe(slot, 2000).collect { list ->
                adapter.items = list
                summary.text = "نمایش ${list.size} مورد اخیر | ناموفق: ${list.count { it.status == St.FAILED }} | موفق/تحویل: ${list.count { it.status == St.SENT || it.status == St.DELIVERED }}"
            }
        }
    }

    private fun export(uri: Uri) {
        val app = requireContext().applicationContext
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    val sb = StringBuilder("phone,name,sim_slot,sim_operator,datetime_jalali,datetime_iso,text,status,delivery,error\n")
                    val iso = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
                    for (l in db.logs().export(slot)) {
                        val delivery = when (l.status) {
                            St.DELIVERED -> "تحویل شد"
                            St.SENT -> "گزارش تحویل دریافت نشد"
                            else -> ""
                        }
                        sb.append(Csv.esc(l.phone)).append(',').append(Csv.esc(l.name)).append(',').append(l.simSlot + 1).append(',')
                            .append(Csv.esc(l.simLabel)).append(',').append(Jalali.format(l.createdAt)).append(',')
                            .append(iso.format(java.util.Date(l.createdAt))).append(',').append(Csv.esc(l.text)).append(',')
                            .append(Csv.esc(St.fa(l.status))).append(',').append(Csv.esc(delivery)).append(',')
                            .append(Csv.esc(l.error)).append('\n')
                    }
                    sb.toString()
                }
                ContactIO.writeText(app, uri, text)
                app.toast("گزارش ذخیره شد.")
            } catch (e: Exception) {
                app.toast("خطا در ذخیره: ${e.message}")
            }
        }
    }
}
