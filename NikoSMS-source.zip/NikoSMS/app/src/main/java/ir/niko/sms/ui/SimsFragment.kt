package ir.niko.sms.ui

import android.Manifest
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import ir.niko.sms.data.AppDb
import ir.niko.sms.data.SimStat
import ir.niko.sms.data.St
import ir.niko.sms.util.SimInfo
import ir.niko.sms.util.Sims
import kotlinx.coroutines.launch

class SimsFragment : Fragment() {
    private lateinit var list: LinearLayout
    private var sims: List<SimInfo> = emptyList()
    private var stats: List<SimStat> = emptyList()

    private val perm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { render() }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View {
        val ctx = requireContext()
        val sv = ScrollView(ctx)
        val col = ctx.vbox()
        sv.addView(col)
        col.addView(ctx.tv("سیم‌کارت‌های فعال", 16f, true))
        list = LinearLayout(ctx)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        col.addView(ctx.btn("اعطای مجوز خواندن وضعیت تلفن", true) { perm.launch(Manifest.permission.READ_PHONE_STATE) })
        col.addView(ctx.tv("اطلاعات از APIهای رسمی SubscriptionManager/TelephonyManager خوانده می‌شود؛ بدون روت.", 11f, false, C.GRAY))
        viewLifecycleOwner.lifecycleScope.launch {
            AppDb.get(ctx).logs().observeSimStats().collect { stats = it; render() }
        }
        return sv
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        if (!isAdded) return
        val ctx = requireContext()
        sims = Sims.active(ctx)
        list.removeAllViews()
        if (sims.isEmpty()) {
            list.addView(ctx.tv("سیم‌کارت فعالی یافت نشد یا مجوز داده نشده است.", 13f, false, C.ORANGE))
            return
        }
        for (s in sims) {
            val mine = stats.filter { it.subId == s.subId }
            fun n(vararg st: String) = mine.filter { it.status in st }.sumOf { it.cnt }
            val card = ctx.vbox(10)
            card.setBackgroundColor(C.CARD)
            card.addView(ctx.tv("${s.label}", 15f, true))
            card.addView(ctx.tv("نام نمایشی: ${s.displayName} | وضعیت: ${if (s.ready) "آماده" else "غیرفعال"}", 12f, false, C.GRAY))
            card.addView(
                ctx.tv(
                    "گزارش این خط — موفق: ${n(St.SENT, St.DELIVERED)} | ناموفق: ${n(St.FAILED)} | در انتظار: ${n(St.PENDING, St.SENDING)}",
                    12f
                )
            )
            list.add(card, m = 4)
        }
    }
}
