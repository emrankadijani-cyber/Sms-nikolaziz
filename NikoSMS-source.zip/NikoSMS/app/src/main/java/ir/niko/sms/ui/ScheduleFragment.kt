package ir.niko.sms.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ir.niko.sms.data.AppDb
import ir.niko.sms.data.JobSt
import ir.niko.sms.data.ScheduledJob
import ir.niko.sms.data.St
import ir.niko.sms.sms.Scheduler
import ir.niko.sms.sms.SendService
import ir.niko.sms.sms.SendState
import ir.niko.sms.util.Jalali
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class JobRow(val title: TextView, val sub: TextView, val state: TextView, val cancel: View)

class ScheduleFragment : Fragment() {
    private lateinit var db: AppDb
    private lateinit var queueTv: TextView
    private lateinit var stateTv: TextView
    private var pendingCount = 0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View {
        val ctx = requireContext()
        db = AppDb.get(ctx)
        val root = ctx.vbox()

        root.addView(ctx.tv("صف ارسال", 16f, true))
        queueTv = ctx.tv("", 13f)
        stateTv = ctx.tv("", 12f, false, C.GRAY)
        root.addView(queueTv)
        root.addView(stateTv)

        val r = ctx.hbox()
        r.add(ctx.btn("توقف موقت", true) {
            ctx.confirm("توقف موقت", "ارسال پس از پیامک جاری متوقف می‌شود و موارد باقی‌مانده در صف می‌ماند.") { SendService.pause(ctx) }
        }, 0, -2, 1f, 2)
        r.add(ctx.btn("ادامه") {
            if (pendingCount == 0) ctx.toast("موردی در صف نیست.")
            else ctx.confirm("ادامه ارسال", "$pendingCount پیامک در انتظار ارسال است. ادامه می‌دهید؟") { SendService.start(ctx) }
        }, 0, -2, 1f, 2)
        r.add(ctx.btn("توقف و لغو صف", true) {
            ctx.confirm("لغو صف", "همه پیامک‌های در انتظار لغو می‌شوند. ادامه می‌دهید؟", "لغو صف") { SendService.stop(ctx) }
        }, 0, -2, 1f, 2)
        root.addView(r)

        root.add(ctx.tv("زمان‌بندی‌ها (برای ثبت مورد جدید از تب «ارسال پیامک» دکمه «زمان‌بندی» را بزنید)", 13f, true, C.GRAY), m = 4)

        val adapter = RowAdapter<ScheduledJob, JobRow>({ c ->
            val col = c.vbox(8)
            val t = c.tv("", 14f, true)
            val s = c.tv("", 12f, false, C.GRAY)
            val st = c.tv("", 12f, true, C.ORANGE)
            val cancel = c.btn("لغو زمان‌بندی", true) {}
            col.addView(t); col.addView(s); col.addView(st); col.addView(cancel)
            Pair<View, JobRow>(col, JobRow(t, s, st, cancel))
        }, { h, j ->
            h.title.text = Jalali.format(j.triggerAt).substring(0, 16) + " — ${j.recipientCount} گیرنده"
            h.sub.text = j.simLabel + " | " + j.text.take(60)
            h.state.text = JobSt.fa(j.state)
            h.cancel.visibility = if (j.state == JobSt.WAITING) View.VISIBLE else View.GONE
            h.cancel.setOnClickListener {
                ctx.confirm("لغو زمان‌بندی", "این زمان‌بندی لغو شود؟") {
                    Scheduler.cancel(ctx, j.id)
                    viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) { db.jobs().setState(j.id, JobSt.CANCELED) }
                }
            }
        })
        val rv = RecyclerView(ctx)
        rv.layoutManager = LinearLayoutManager(ctx)
        rv.adapter = adapter
        root.add(rv, -1, 0, 1f)

        val lo = viewLifecycleOwner.lifecycleScope
        lo.launch { db.jobs().observe().collect { adapter.items = it } }
        lo.launch {
            combine(
                db.logs().observeCount(St.PENDING), db.logs().observeCount(St.SENDING),
                db.logs().observeCount(St.SENT), db.logs().observeCount(St.DELIVERED)
            ) { p, s, ok, d -> intArrayOf(p, s, ok, d) }
                .combine(db.logs().observeCount(St.FAILED)) { a, f -> a + f }
                .collect { a ->
                    pendingCount = a[0]
                    queueTv.text = "در انتظار: ${a[0]} | در حال ارسال: ${a[1]} | ارسال‌شده: ${a[2]} | تحویل‌شده: ${a[3]} | ناموفق: ${a[4]}"
                }
        }
        lo.launch {
            combine(SendState.running, SendState.message) { run, msg -> (if (run) "● در حال اجرا — " else "○ غیرفعال — ") + msg }
                .collect { stateTv.text = it }
        }
        return root
    }
}
