package ir.niko.sms.sms

import ir.niko.sms.data.AppDb
import ir.niko.sms.data.Contact
import ir.niko.sms.data.SmsLog
import ir.niko.sms.data.St
import ir.niko.sms.util.SimInfo
import ir.niko.sms.util.SmsCalc
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SelectionState {
    val ids = LinkedHashSet<Long>()
}

object Recipients {
    data class Resolved(val ok: List<Contact>, val noConsent: Int, val blacklisted: Int, val source: String)

    /** فقط مخاطبین دارای رضایت و خارج از فهرست سیاه */
    suspend fun resolve(db: AppDb, category: String): Resolved = withContext(Dispatchers.IO) {
        val all = db.contacts().all()
        val sel = SelectionState.ids.toSet()
        val (base, src) = when {
            sel.isNotEmpty() -> all.filter { it.id in sel } to "مخاطبین انتخاب‌شده (${sel.size})"
            category.isNotEmpty() -> all.filter { it.category == category } to "دسته «$category»"
            else -> all to "همه مخاطبین"
        }
        var nc = 0
        var bl = 0
        val ok = ArrayList<Contact>()
        for (c in base) {
            if (c.blacklisted) bl++ else if (!c.consent) nc++ else ok.add(c)
        }
        Resolved(ok, nc, bl, src)
    }
}

object Queue {
    data class Enqueued(val added: Int, val skippedDuplicates: Int)

    /** ردیف‌های PENDING می‌سازد؛ شماره‌هایی که همین متن را قبلاً دریافت کرده‌اند/در صف‌اند حذف می‌شوند. */
    suspend fun enqueue(db: AppDb, text: String, sim: SimInfo, recipients: List<Contact>): Enqueued =
        withContext(Dispatchers.IO) {
            val already = db.logs().phonesAlready(text).toHashSet()
            val now = System.currentTimeMillis()
            val parts = SmsCalc.calc(text).parts
            val unique = recipients.distinctBy { it.phone }
            val rows = unique.filter { it.phone !in already }.map {
                SmsLog(
                    batchId = now, phone = it.phone, name = it.name, subId = sim.subId, simSlot = sim.slot,
                    simLabel = sim.label, createdAt = now, text = text, status = St.PENDING,
                    partsTotal = parts, updatedAt = now
                )
            }
            db.logs().insertAll(rows)
            Enqueued(rows.size, recipients.size - rows.size)
        }
}
