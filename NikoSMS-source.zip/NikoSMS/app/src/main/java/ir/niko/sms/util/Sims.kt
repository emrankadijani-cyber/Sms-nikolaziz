package ir.niko.sms.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

data class SimInfo(val subId: Int, val slot: Int, val operatorName: String, val displayName: String, val ready: Boolean) {
    val label: String get() = "سیم ${slot + 1} – $operatorName"
}

object Sims {
    private fun operatorOf(i: SubscriptionInfo): String {
        val code = if (Build.VERSION.SDK_INT >= 29) {
            (i.mccString ?: "") + (i.mncString ?: "")
        } else {
            @Suppress("DEPRECATION")
            i.mcc.toString() + String.format("%02d", i.mnc)
        }
        return when (code) {
            "43211" -> "همراه اول"
            "43235" -> "ایرانسل"
            "43220" -> "رایتل"
            else -> i.carrierName?.toString()?.ifBlank { null } ?: "نامشخص"
        }
    }

    fun hasPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    fun active(ctx: Context): List<SimInfo> {
        if (!hasPermission(ctx)) return emptyList()
        return try {
            val sm = ctx.getSystemService(SubscriptionManager::class.java) ?: return emptyList()
            val tm = ctx.getSystemService(TelephonyManager::class.java) ?: return emptyList()
            val list = sm.activeSubscriptionInfoList ?: emptyList()
            list.map { i ->
                val t = tm.createForSubscriptionId(i.subscriptionId)
                SimInfo(
                    i.subscriptionId, i.simSlotIndex, operatorOf(i),
                    i.displayName?.toString() ?: "",
                    t.simState == TelephonyManager.SIM_STATE_READY
                )
            }.sortedBy { it.slot }
        } catch (e: SecurityException) {
            emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
}
