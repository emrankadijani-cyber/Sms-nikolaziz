package ir.niko.sms.data

import android.content.Context
import android.net.Uri
import ir.niko.sms.util.Csv
import ir.niko.sms.util.PhoneNormalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ContactIO {
    data class Result(val rows: Int, val added: Int, val updated: Int, val duplicates: Int, val invalid: Int)

    /** ستون‌ها: نام, شماره, دسته, رضایت(1/0), سیاه‌لیست(1/0) */
    suspend fun importCsv(ctx: Context, db: AppDb, uri: Uri, overwrite: Boolean): Result = withContext(Dispatchers.IO) {
        val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
        val lines = text.removePrefix("\uFEFF").lines().filter { it.isNotBlank() }
        val delim = if (lines.firstOrNull()?.let { ';' in it && ',' !in it } == true) ';' else ','
        val yes = setOf("1", "true", "yes", "بله", "دارد")
        val seen = HashSet<String>()
        val list = ArrayList<Contact>()
        var invalid = 0
        var dupInFile = 0
        var rows = 0
        val now = System.currentTimeMillis()
        lines.forEachIndexed { idx, line ->
            val c = Csv.parseLine(line, delim)
            val nameRaw = c[0]
            val phoneRaw = if (c.size == 1) c[0] else c[1]
            val phone = PhoneNormalizer.normalize(phoneRaw)
            if (phone == null) {
                if (idx != 0) invalid++ // سطر اول احتمالاً عنوان ستون‌هاست
                return@forEachIndexed
            }
            rows++
            if (!seen.add(phone)) { dupInFile++; return@forEachIndexed }
            val consentS = (c.getOrNull(3) ?: "").lowercase()
            val blS = (c.getOrNull(4) ?: "").lowercase()
            val consent = consentS in yes
            list.add(
                Contact(
                    name = if (c.size == 1 || nameRaw.isBlank()) phone else nameRaw,
                    phone = phone,
                    category = c.getOrNull(2) ?: "",
                    consent = consent,
                    consentAt = if (consent) now else 0,
                    blacklisted = blS in yes
                )
            )
        }
        val ids = db.contacts().insertAll(list)
        var added = 0
        var updated = 0
        var dup = dupInFile
        ids.forEachIndexed { i, id ->
            if (id != -1L) added++
            else if (overwrite) {
                val c = list[i]
                db.contacts().updateByPhone(c.phone, c.name, c.category, c.consent, c.consentAt, c.blacklisted)
                updated++
            } else dup++
        }
        Result(rows, added, updated, dup, invalid)
    }

    suspend fun exportCsv(db: AppDb): String = withContext(Dispatchers.IO) {
        val sb = StringBuilder("name,phone,category,consent,blacklist\n")
        for (c in db.contacts().all().sortedBy { it.name }) {
            sb.append(Csv.esc(c.name)).append(',').append(c.phone).append(',').append(Csv.esc(c.category)).append(',')
                .append(if (c.consent) 1 else 0).append(',').append(if (c.blacklisted) 1 else 0).append('\n')
        }
        sb.toString()
    }

    suspend fun writeText(ctx: Context, uri: Uri, text: String) = withContext(Dispatchers.IO) {
        ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(("\uFEFF" + text).toByteArray(Charsets.UTF_8)) }
        Unit
    }
}
