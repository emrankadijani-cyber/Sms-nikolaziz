package ir.niko.sms.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

object C {
    val RED = Color.parseColor("#C62828")
    val GRAY = Color.parseColor("#616161")
    val GREEN = Color.parseColor("#2E7D32")
    val ORANGE = Color.parseColor("#EF6C00")
    val TEXT = Color.parseColor("#212121")
    val CARD = Color.parseColor("#F5F5F5")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun Context.toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

fun Context.tv(text: String = "", sp: Float = 14f, bold: Boolean = false, color: Int = C.TEXT): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = sp
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    t.setTextColor(color)
    return t
}

fun Context.btn(text: String, outlined: Boolean = false, onClick: () -> Unit): MaterialButton {
    val b = if (outlined) MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
    else MaterialButton(this)
    b.text = text
    b.isAllCaps = false
    b.setOnClickListener { onClick() }
    return b
}

fun Context.vbox(pad: Int = 12): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    return l
}

fun Context.hbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.HORIZONTAL
    l.gravity = Gravity.CENTER_VERTICAL
    return l
}

fun LinearLayout.add(v: View, w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT,
                     weight: Float = 0f, m: Int = 0): View {
    val p = LinearLayout.LayoutParams(w, h, weight)
    val px = context.dp(m)
    p.setMargins(px, px, px, px)
    addView(v, p)
    return v
}

fun Context.field(hint: String, init: String = "", numeric: Boolean = false, multiline: Boolean = false): EditText {
    val e = EditText(this)
    e.hint = hint
    e.setText(init)
    e.inputType = when {
        numeric -> InputType.TYPE_CLASS_NUMBER
        multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        else -> InputType.TYPE_CLASS_TEXT
    }
    if (multiline) { e.minLines = 4; e.gravity = Gravity.TOP or Gravity.START }
    return e
}

fun Context.confirm(title: String, msg: String, ok: String = "تأیید", onOk: () -> Unit) {
    AlertDialog.Builder(this).setTitle(title).setMessage(msg)
        .setPositiveButton(ok) { _, _ -> onOk() }
        .setNegativeButton("انصراف", null).show()
}

fun Context.input(title: String, hint: String, init: String = "", onOk: (String) -> Unit) {
    val e = field(hint, init)
    val box = vbox(20)
    box.addView(e)
    AlertDialog.Builder(this).setTitle(title).setView(box)
        .setPositiveButton("تأیید") { _, _ -> onOk(e.text.toString().trim()) }
        .setNegativeButton("انصراف", null).show()
}

class RowAdapter<T, H : Any>(
    private val make: (Context) -> Pair<View, H>,
    private val bind: (H, T) -> Unit
) : RecyclerView.Adapter<RowAdapter.VH<H>>() {
    var items: List<T> = emptyList()
        set(v) { field = v; notifyDataSetChanged() }

    class VH<H>(v: View, val h: H) : RecyclerView.ViewHolder(v)

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH<H> {
        val (v, h) = make(p.context)
        v.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        return VH(v, h)
    }

    override fun onBindViewHolder(holder: VH<H>, position: Int) = bind(holder.h, items[position])
    override fun getItemCount() = items.size
}
