package ir.niko.sms.ui

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ScrollView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.switchmaterial.SwitchMaterial
import ir.niko.sms.data.AppDb
import ir.niko.sms.data.ContactIO
import ir.niko.sms.data.Prefs
import ir.niko.sms.sms.SelectionState
import ir.niko.sms.sms.SendService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsFragment : Fragment() {
    private lateinit var db: AppDb

    private val backupOut = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) doBackup(uri)
    }
    private val restoreIn = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) doRestore(uri)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View {
        val ctx = requireContext()
        db = AppDb.get(ctx)
        val prefs = Prefs(ctx)
        val sv = ScrollView(ctx)
        val col = ctx.vbox()
        sv.addView(col)

        col.addView(ctx.tv("محدودیت‌های ارسال (برای رعایت قوانین اپراتور)", 15f, true))
        val delay: EditText = ctx.field("فاصله بین دو پیامک (ثانیه، حداقل ۱)", prefs.delaySec.toString(), numeric = true)
        val batch: EditText = ctx.field("تعداد مخاطب در هر دسته", prefs.batchSize.toString(), numeric = true)
        val pause: EditText = ctx.field("استراحت بین دسته‌ها (ثانیه)", prefs.batchPauseSec.toString(), numeric = true)
        col.addView(ctx.tv("فاصله بین دو پیامک (ثانیه)", 12f, false, C.GRAY)); col.addView(delay)
        col.addView(ctx.tv("تعداد در هر دسته", 12f, false, C.GRAY)); col.addView(batch)
        col.addView(ctx.tv("استراحت بین دسته‌ها (ثانیه)", 12f, false, C.GRAY)); col.addView(pause)
        val sw = SwitchMaterial(ctx)
        sw.text = "درخواست گزارش تحویل (در صورت پشتیبانی شبکه)"
        sw.isChecked = prefs.requestDelivery
        col.addView(sw)
        col.addView(ctx.btn("ذخیره تنظیمات") {
            prefs.delaySec = (delay.text.toString().toIntOrNull() ?: 3).coerceIn(1, 3600)
            prefs.batchSize = (batch.text.toString().toIntOrNull() ?: 20).coerceIn(1, 500)
            prefs.batchPauseSec = (pause.text.toString().toIntOrNull() ?: 60).coerceIn(0, 3600)
            prefs.requestDelivery = sw.isChecked
            ctx.toast("ذخیره شد.")
        })

        col.add(ctx.tv("پشتیبان‌گیری محلی (فایل CSV)", 15f, true), m = 6)
        col.addView(ctx.btn("تهیه نسخه پشتیبان مخاطبین", true) { backupOut.launch("niko-contacts-backup.csv") })
        col.addView(ctx.btn("بازیابی از نسخه پشتیبان", true) { restoreIn.launch(arrayOf("text/*", "application/octet-stream")) })

        col.add(ctx.tv("حذف اطلاعات", 15f, true), m = 6)
        col.addView(ctx.btn("حذف همه گزارش‌ها", true) {
            ctx.confirm("حذف گزارش‌ها", "تمام سوابق ارسال حذف شود؟", "حذف") {
                lifecycleScopeIo { db.logs().deleteAll() }
                ctx.toast("گزارش‌ها حذف شد.")
            }
        })
        col.addView(ctx.btn("حذف کامل همه داده‌ها", true) {
            ctx.confirm("حذف کامل", "مخاطبین، گزارش‌ها، زمان‌بندی‌ها و تنظیمات برای همیشه حذف می‌شوند. ادامه می‌دهید؟", "حذف کامل") {
                SendService.stop(ctx)
                SelectionState.ids.clear()
                lifecycleScopeIo { db.clearAllTables() }
                prefs.clear()
                ctx.toast("همه داده‌ها حذف شد.")
            }
        })

        col.add(
            ctx.tv(
                "حریم خصوصی: برنامه مجوز اینترنت ندارد؛ هیچ داده‌ای از گوشی خارج نمی‌شود. داده‌ها در حافظه خصوصی برنامه ذخیره می‌شوند و پشتیبان‌گیری ابری اندروید غیرفعال است. هیچ سرویس تبلیغاتی یا ردیابی وجود ندارد.\n\nنسخه 0.4",
                11f, false, C.GRAY
            ), m = 6
        )
        return sv
    }

    private fun lifecycleScopeIo(block: suspend () -> Unit) {
        viewLifecycleOwner.lifecycleScope.launch { withContext(Dispatchers.IO) { block() } }
    }

    private fun doBackup(uri: Uri) {
        val app = requireContext().applicationContext
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                ContactIO.writeText(app, uri, ContactIO.exportCsv(db))
                app.toast("نسخه پشتیبان ذخیره شد.")
            } catch (e: Exception) { app.toast("خطا: ${e.message}") }
        }
    }

    private fun doRestore(uri: Uri) {
        val app = requireContext().applicationContext
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val r = ContactIO.importCsv(app, db, uri, true)
                app.toast("بازیابی شد — جدید: ${r.added} | به‌روزرسانی: ${r.updated} | نامعتبر: ${r.invalid}")
            } catch (e: Exception) { app.toast("خطا: ${e.message}") }
        }
    }
}
