package ir.niko.sms.util

object Csv {
    fun parseLine(line: String, delim: Char = ','): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            if (inQuotes) {
                if (ch == '"') {
                    if (i + 1 < line.length && line[i + 1] == '"') { sb.append('"'); i++ } else inQuotes = false
                } else sb.append(ch)
            } else if (ch == '"') inQuotes = true
            else if (ch == delim) { out.add(sb.toString()); sb.setLength(0) }
            else sb.append(ch)
            i++
        }
        out.add(sb.toString())
        return out.map { it.trim() }
    }

    /** escape برای نوشتن؛ همچنین جلوگیری از CSV-injection در اکسل */
    fun esc(s: String): String {
        var t = s.replace("\r", " ").replace("\n", " ")
        if (t.isNotEmpty() && t[0] in "=+-@") t = "'$t"
        return if (t.contains(',') || t.contains('"')) "\"" + t.replace("\"", "\"\"") + "\"" else t
    }
}
