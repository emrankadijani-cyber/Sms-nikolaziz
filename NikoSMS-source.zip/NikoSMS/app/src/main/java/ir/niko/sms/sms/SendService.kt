package ir.niko.sms.sms

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import android.telephony.SmsManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import ir.niko.sms.data.AppDb
import ir.niko.sms.data.Prefs
import ir.niko.sms.data.SmsLog
import ir.niko.sms.data.St
import ir.niko.sms.util.Sims
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow

object SendState {
    val running = MutableStateFlow(false)
    val message = MutableStateFlow("")
    @Volatile var pauseRequested = false
    @Volatile var stopRequested = false
    @Volatile var autoStopReason: String? = null
    @Volatile private var fails = 0

    fun reset() { pauseRequested = false; stopRequested = false; autoStopReason = null; fails = 0 }
    fun shouldHalt() = pauseRequested || stopRequested || autoStopReason != null
    fun noteSuccess() { fails = 0 }
    fun noteFailure() {
        fails++
        if (fails >= 3) autoStop("۳ خطای متوالی؛ برای رعایت محدودیت‌های اپراتور ارسال متوقف شد")
    }
    fun autoStop(reason: String) { if (autoStopReason == null) autoStopReason = reason }
}

class SendService : Service() {
    companion object {
        const val ACTION_START = "ir.niko.sms.START"
        const val ACTION_PAUSE = "ir.niko.sms.PAUSE"
        const val ACTION_STOP = "ir.niko.sms.STOP"
        const val ACTION_SENT = "ir.niko.sms.SENT"
        const val ACTION_DELIVERED = "ir.niko.sms.DELIVERED"
        private const val CHANNEL = "niko_send"
        private const val NOTIF_ID = 77

        fun start(ctx: Context) =
            ContextCompat.startForegroundService(ctx, Intent(ctx, SendService::class.java).setAction(ACTION_START))
        fun pause(ctx: Context) { ctx.startService(Intent(ctx, SendService::class.java).setAction(ACTION_PAUSE)) }
        fun stop(ctx: Context) { ctx.startService(Intent(ctx, SendService::class.java).setAction(ACTION_STOP)) }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForeground(NOTIF_ID, notif("آماده‌سازی ارسال…"))
                if (job?.isActive != true) {
                    SendState.reset()
                    job = scope.launch { runLoop() }
                }
            }
            ACTION_PAUSE -> {
                SendState.pauseRequested = true
                if (job?.isActive != true) stopSelf()
            }
            ACTION_STOP -> {
                SendState.stopRequested = true
                scope.launch {
                    AppDb.get(this@SendService).logs().cancelPending("توقف توسط کاربر", System.currentTimeMillis())
                    if (job?.isActive != true) stopSelf()
                }
            }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun notif(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "ارسال پیامک", NotificationManager.IMPORTANCE_LOW))
        }
        val pauseIntent = PendingIntent.getService(
            this, 1, Intent(this, SendService::class.java).setAction(ACTION_PAUSE), PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("Niko SMS")
            .setContentText(text)
            .setOngoing(true)
            .addAction(0, "توقف موقت", pauseIntent)
            .build()
    }

    private fun update(text: String) {
        SendState.message.value = text
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notif(text))
    }

    private suspend fun delayInterruptible(ms: Long) {
        var left = ms
        while (left > 0 && !SendState.shouldHalt()) {
            delay(minOf(250L, left))
            left -= 250L
        }
    }

    private suspend fun runLoop() {
        val db = AppDb.get(this)
        val prefs = Prefs(this)
        val pm = getSystemService(PowerManager::class.java)
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "niko:send")
        wl.acquire(6 * 60 * 60 * 1000L)
        SendState.running.value = true
        try {
            db.logs().recoverStuck(System.currentTimeMillis(), System.currentTimeMillis() - 15 * 60_000L)
            var inBatch = 0
            var done = 0
            while (true) {
                if (SendState.shouldHalt()) break
                val row = db.logs().nextPending() ?: break
                val sim = Sims.active(this).firstOrNull { it.subId == row.subId && it.ready }
                val now = System.currentTimeMillis()
                if (sim == null) {
                    db.logs().mark(row.id, St.FAILED, "سیم‌کارت غیرفعال یا خارج‌شده / مجوز تلفن", now)
                    SendState.noteFailure()
                    continue
                }
                db.logs().mark(row.id, St.SENDING, "", now)
                try {
                    sendOne(db, row, prefs.requestDelivery)
                } catch (e: Exception) {
                    db.logs().mark(row.id, St.FAILED, e.javaClass.simpleName + ": " + (e.message ?: ""), System.currentTimeMillis())
                    SendState.noteFailure()
                }
                done++
                inBatch++
                val left = db.logs().count(St.PENDING)
                update("ارسال شد: $done | باقی‌مانده: $left")
                delayInterruptible(maxOf(1, prefs.delaySec) * 1000L)
                if (inBatch >= maxOf(1, prefs.batchSize) && left > 0 && !SendState.shouldHalt()) {
                    inBatch = 0
                    var rest = prefs.batchPauseSec
                    while (rest > 0 && !SendState.shouldHalt()) {
                        update("استراحت بین دسته‌ها: $rest ثانیه | باقی‌مانده: $left")
                        delay(1000)
                        rest--
                    }
                }
            }
        } finally {
            if (wl.isHeld) wl.release()
            SendState.message.value = when {
                SendState.autoStopReason != null -> "توقف خودکار: " + SendState.autoStopReason
                SendState.stopRequested -> "ارسال متوقف شد."
                SendState.pauseRequested -> "ارسال موقتاً متوقف است؛ برای ادامه «ادامه» را بزنید."
                else -> "صف ارسال تمام شد."
            }
            SendState.running.value = false
            stopForeground(true)
            stopSelf()
        }
    }

    @Suppress("DEPRECATION")
    private suspend fun sendOne(db: AppDb, row: SmsLog, delivery: Boolean) {
        val sm = SmsManager.getSmsManagerForSubscriptionId(row.subId)
        val parts = sm.divideMessage(row.text)
        db.logs().setParts(row.id, parts.size, System.currentTimeMillis())
        val sent = ArrayList<PendingIntent>()
        val deliv = ArrayList<PendingIntent>()
        for (i in parts.indices) {
            sent.add(pi(ACTION_SENT, row.id, i))
            if (delivery) deliv.add(pi(ACTION_DELIVERED, row.id, i))
        }
        if (parts.size == 1) {
            sm.sendTextMessage(row.phone, null, parts[0], sent[0], deliv.getOrNull(0))
        } else {
            sm.sendMultipartTextMessage(row.phone, null, parts, sent, if (delivery) deliv else null)
        }
    }

    private fun pi(action: String, id: Long, idx: Int): PendingIntent {
        val k = if (action == ACTION_SENT) 0 else 1
        val i = Intent(this, SmsResultReceiver::class.java)
            .setAction(action)
            .setData(Uri.parse("niko://sms/$id/$idx/$k"))
            .putExtra("id", id)
            .putExtra("part", idx)
        return PendingIntent.getBroadcast(this, (id * 1000 + idx * 2 + k).toInt(), i, PendingIntent.FLAG_UPDATE_CURRENT)
    }
}
