package ir.niko.sms.ui

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.tabs.TabLayout
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private var containerId = 0

    override fun attachBaseContext(base: Context) {
        val loc = Locale("fa", "IR")
        Locale.setDefault(loc)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(loc)
        cfg.setLayoutDirection(loc)
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.WHITE)

        val title = tv("Niko SMS — پنل پیامک نیکو لذیذ", 18f, true, Color.WHITE)
        title.setBackgroundColor(C.RED)
        title.setPadding(dp(16), dp(14), dp(16), dp(14))
        root.addView(title, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val tabs = TabLayout(this)
        tabs.tabMode = TabLayout.MODE_SCROLLABLE
        tabs.setSelectedTabIndicatorColor(C.RED)
        tabs.setTabTextColors(C.GRAY, C.RED)
        val names = listOf("مخاطبین", "ارسال پیامک", "زمان‌بندی", "گزارش ارسال", "سیم‌کارت‌ها", "تنظیمات")
        names.forEach { tabs.addTab(tabs.newTab().setText(it)) }
        root.addView(tabs, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val container = FrameLayout(this)
        containerId = View.generateViewId()
        container.id = containerId
        root.addView(container, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) { show(tab.position) }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
        val idx = savedInstanceState?.getInt("tab", 0) ?: 0
        tabs.getTabAt(idx)?.select()
        show(idx)
        tabIndex = idx
    }

    private var tabIndex = 0

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tabIndex)
    }

    private fun show(i: Int) {
        tabIndex = i
        val f: Fragment = when (i) {
            0 -> ContactsFragment()
            1 -> ComposeFragment()
            2 -> ScheduleFragment()
            3 -> ReportsFragment()
            4 -> SimsFragment()
            else -> SettingsFragment()
        }
        supportFragmentManager.beginTransaction().replace(containerId, f).commitAllowingStateLoss()
    }
}
