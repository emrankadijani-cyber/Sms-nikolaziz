package ir.niko.sms.ui

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ir.niko.sms.data.AppDb
import ir.niko.sms.data.Contact
import ir.niko.sms.data.ContactIO
import ir.niko.sms.sms.SelectionState
import ir.niko.sms.util.PhoneNormalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ContactRow(val root: View, val cb: CheckBox, val name: TextView, val sub: TextView, val badge: TextView)

class ContactsFragment : Fragment() {
    private lateinit var db: AppDb
    private var all: List<Contact> = emptyList()
    private var shown: List<Contact> = emptyList()
    private var query = ""
    private lateinit var adapter: RowAdapter<Contact, ContactRow>
    private lateinit var summary: TextView

    private val permContacts = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) importFromPhone() else requireContext().toast("بدون مجوز مخاطبین، دریافت از گوشی ممکن نیست.")
    }
    private val pickCsv = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importCsv(uri)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View {
        val ctx = requireContext()
        db = AppDb.get(ctx)
        val root = ctx.vbox(8)

        val r1 = ctx.hbox()
        r1.add(ctx.btn("از گوشی", true) { fromPhone() }, 0, -2, 1f, 2)
        r1.add(ctx.btn("ورود CSV", true) { csvInfo() }, 0, -2, 1f, 2)
        r1.add(ctx.btn("افزودن", true) { addDialog() }, 0, -2, 1f, 2)
        root.addView(r1)

        val search = ctx.field("جست‌وجو بر اساس نام یا شماره")
        search.doAfterTextChanged { query = it?.toString()?.trim() ?: ""; applyFilter() }
        root.addView(search)

        val r2 = ctx.hbox()
        r2.add(ctx.btn("انتخاب همه", true) { shown.forEach { SelectionState.ids.add(it.id) }; refreshUi() }, 0, -2, 1f, 2)
        r2.add(ctx.btn("لغو انتخاب", true) { SelectionState.ids.clear(); refreshUi() }, 0, -2, 1f, 2)
        r2.add(ctx.btn("عملیات") { actions() }, 0, -2, 1f, 2)
        root.addView(r2)

        summary = ctx.tv("", 12f, false, C.GRAY)
        root.addView(summary)

        adapter = RowAdapter<Contact, ContactRow>({ c ->
            val row = c.hbox()
            row.setPadding(c.dp(6), c.dp(8), c.dp(6), c.dp(8))
            val cb = CheckBox(c)
            cb.isClickable = false
            cb.isFocusable = false
            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            val n = c.tv("", 15f, true)
            val s = c.tv("", 12f, false, C.GRAY)
            col.addView(n)
            col.addView(s)
            val b = c.tv("", 12f, true)
            row.addView(cb)
            row.add(col, 0, -2, 1f, 4)
            row.addView(b)
            Pair<View, ContactRow>(row, ContactRow(row, cb, n, s, b))
        }, { h, item ->
            h.cb.isChecked = item.id in SelectionState.ids
            h.name.text = item.name
            h.sub.text = item.phone + if (item.category.isNotEmpty()) " • ${item.category}" else ""
            when {
                item.blacklisted -> { h.badge.text = "سیاه‌لیست"; h.badge.setTextColor(C.RED) }
                item.consent -> { h.badge.text = "رضایت ✓"; h.badge.setTextColor(C.GREEN) }
                else -> { h.badge.text = "بدون رضایت"; h.badge.setTextColor(C.ORANGE) }
            }
            h.root.setOnClickListener {
                if (!SelectionState.ids.remove(item.id)) SelectionState.ids.add(item.id)
                refreshUi()
            }
        })
        val rv = RecyclerView(ctx)
        rv.layoutManager = LinearLayoutManager(ctx)
        rv.adapter = adapter
        root.add(rv, -1, 0, 1f)
        return root
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        viewLifecycleOwner.lifecycleScope.launch {
            all = withContext(Dispatchers.IO) { db.contacts().all().sortedBy { it.name } }
            applyFilter()
        }
    }

    private fun applyFilter() {
        val q = query
        val qd = PhoneNormalizer.digits(q)
        shown = if (q.isEmpty()) all else all.filter {
            it.name.contains(q, true) || (qd.isNotEmpty() && it.phone.contains(qd))
        }
        refreshUi()
    }

    private fun refreshUi() {
        adapter.items = shown
        val consentCount = all.count { it.consent && !it.blacklisted }
        summary.text = "نمایش ${shown.size} از ${all.size} | انتخاب‌شده: ${SelectionState.ids.size} | مجاز برای ارسال: $consentCount"
    }

    private fun runDb(block: suspend () -> Unit) {
        viewLifecycleOwner.lifecycleScope.launch {
            withContext(Dispatchers.IO) { block() }
            reload()
        }
    }

    // ---- دریافت از گوشی ----
    private fun fromPhone() {
        val ctx = requireContext()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) importFromPhone()
        else permContacts.launch(Manifest.permission.READ_CONTACTS)
    }

    private fun importFromPhone() {
        val app = requireContext().applicationContext
        viewLifecycleOwner.lifecycleScope.launch {
            val res = withContext(Dispatchers.IO) {
                val list = ArrayList<Contact>()
                val seen = HashSet<String>()
                var raw = 0
                var invalid = 0
                var dupInPhone = 0
                app.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                    null, null, null
                )?.use { c ->
                    while (c.moveToNext()) {
                        raw++
                        val name = c.getString(0) ?: ""
                        val n = PhoneNormalizer.normalize(c.getString(1))
                        if (n == null) { invalid++; continue }
                        if (!seen.add(n)) { dupInPhone++; continue }
                        list.add(Contact(name = name.ifBlank { n }, phone = n))
                    }
                }
                val ids = db.contacts().insertAll(list)
                val added = ids.count { it != -1L }
                ContactIO.Result(raw, added, 0, list.size - added + dupInPhone, invalid)
            }
            app.toast("خوانده‌شده: ${res.rows} | افزوده: ${res.added} | تکراری: ${res.duplicates} | نامعتبر (غیرموبایل): ${res.invalid}\nبرای ارسال، رضایت مخاطبین را ثبت کنید.")
            reload()
        }
    }

    // ---- CSV ----
    private fun csvInfo() {
        AlertDialog.Builder(requireContext()).setTitle("ورود از فایل CSV")
            .setMessage("فایل باید UTF-8 باشد. ستون‌ها: نام, شماره, دسته, رضایت, سیاه‌لیست\n(دو ستون آخر اختیاری؛ مقدار 1 یعنی بله).\nستون رضایت را فقط وقتی 1 بگذارید که رضایت مستند دارید؛ در غیر این صورت رضایت «ندارد» ثبت می‌شود.")
            .setPositiveButton("انتخاب فایل") { _, _ -> pickCsv.launch(arrayOf("text/*", "application/vnd.ms-excel", "application/octet-stream")) }
            .setNegativeButton("انصراف", null).show()
    }

    private fun importCsv(uri: Uri) {
        val app = requireContext().applicationContext
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val r = ContactIO.importCsv(app, db, uri, false)
                app.toast("ردیف معتبر: ${r.rows} | افزوده: ${r.added} | تکراری: ${r.duplicates} | نامعتبر: ${r.invalid}")
            } catch (e: Exception) {
                app.toast("خطا در خواندن فایل: ${e.message}")
            }
            reload()
        }
    }

    // ---- افزودن دستی ----
    private fun addDialog() {
        val ctx = requireContext()
        val box = ctx.vbox(16)
        val name = ctx.field("نام")
        val phone = ctx.field("شماره (مثلاً 0912…)")
        val cat = ctx.field("دسته‌بندی (اختیاری)")
        val consent = CheckBox(ctx)
        consent.text = "رضایت دریافت پیامک تبلیغاتی را دارد"
        box.addView(name); box.addView(phone); box.addView(cat); box.addView(consent)
        AlertDialog.Builder(ctx).setTitle("افزودن مخاطب").setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                val p = PhoneNormalizer.normalize(phone.text.toString())
                if (p == null) { ctx.toast("شماره موبایل معتبر نیست."); return@setPositiveButton }
                runDbToast {
                    val c = Contact(
                        name = name.text.toString().trim().ifBlank { p }, phone = p, category = cat.text.toString().trim(),
                        consent = consent.isChecked, consentAt = if (consent.isChecked) System.currentTimeMillis() else 0
                    )
                    if (db.contacts().insertAll(listOf(c))[0] == -1L) "این شماره قبلاً ثبت شده است." else "افزوده شد."
                }
            }
            .setNegativeButton("انصراف", null).show()
    }

    private fun runDbToast(block: suspend () -> String) {
        val app = requireContext().applicationContext
        viewLifecycleOwner.lifecycleScope.launch {
            val msg = withContext(Dispatchers.IO) { block() }
            app.toast(msg)
            reload()
        }
    }

    // ---- عملیات گروهی ----
    private fun actions() {
        val ctx = requireContext()
        val ids = SelectionState.ids.toList()
        if (ids.isEmpty()) { ctx.toast("ابتدا مخاطب انتخاب کنید."); return }
        val items = arrayOf(
            "ثبت رضایت دریافت پیامک تبلیغاتی", "لغو رضایت", "افزودن به فهرست سیاه",
            "حذف از فهرست سیاه", "تعیین دسته‌بندی", "حذف مخاطبین"
        )
        AlertDialog.Builder(ctx).setTitle("عملیات روی ${ids.size} مخاطب").setItems(items) { _, which ->
            when (which) {
                0 -> ctx.confirm("ثبت رضایت", "تأیید می‌کنم این ${ids.size} نفر رضایت صریح خود را برای دریافت پیامک تبلیغاتی اعلام کرده‌اند و رضایت‌شان قابل اثبات است.") {
                    runDb { ids.chunked(500).forEach { db.contacts().setConsent(it, true, System.currentTimeMillis()) } }
                }
                1 -> runDb { ids.chunked(500).forEach { db.contacts().setConsent(it, false, 0) } }
                2 -> runDb { ids.chunked(500).forEach { db.contacts().setBlacklist(it, true) } }
                3 -> runDb { ids.chunked(500).forEach { db.contacts().setBlacklist(it, false) } }
                4 -> ctx.input("دسته‌بندی", "نام دسته") { cat -> runDb { ids.chunked(500).forEach { db.contacts().setCategory(it, cat) } } }
                5 -> ctx.confirm("حذف مخاطبین", "${ids.size} مخاطب حذف شود؟ این کار قابل بازگشت نیست.", "حذف") {
                    SelectionState.ids.clear()
                    runDb { ids.chunked(500).forEach { db.contacts().delete(it) } }
                }
            }
        }.show()
    }
}
