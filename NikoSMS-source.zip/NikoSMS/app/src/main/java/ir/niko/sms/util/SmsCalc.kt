package ir.niko.sms.util

import android.telephony.SmsMessage

data class SmsInfo(val chars: Int, val parts: Int, val unicode: Boolean, val remaining: Int)

object SmsCalc {
    fun calc(text: String): SmsInfo {
        if (text.isEmpty()) return SmsInfo(0, 0, false, 0)
        return try {
            val r = SmsMessage.calculateLength(text, false) // [parts, codeUnits, remaining, encoding]
            SmsInfo(text.length, r[0], r[3] == 3, r[2])     // 3 = UCS-2 (فارسی)
        } catch (e: Exception) {
            SmsInfo(text.length, 1, true, 0)
        }
    }
}
