package ir.niko.sms.util

object PhoneNormalizer {
    private val regex = Regex("^09\\d{9}$")

    /** فقط ارقام (انگلیسی، فارسی، عربی) را برمی‌گرداند. */
    fun digits(raw: String): String {
        val sb = StringBuilder()
        for (ch in raw) {
            when (ch) {
                in '0'..'9' -> sb.append(ch)
                in '\u06F0'..'\u06F9' -> sb.append('0' + (ch - '\u06F0'))
                in '\u0660'..'\u0669' -> sb.append('0' + (ch - '\u0660'))
                else -> {}
            }
        }
        return sb.toString()
    }

    /** 09xxxxxxxxx ، 989xxxxxxxxx ، +989... ، 00989... ، 9xxxxxxxxx  ->  09xxxxxxxxx ؛ نامعتبر -> null */
    fun normalize(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        var d = digits(raw)
        d = when {
            d.startsWith("0098") && d.length == 14 -> d.substring(4)
            d.startsWith("98") && d.length == 12 -> d.substring(2)
            else -> d
        }
        if (d.length == 10 && d.startsWith("9")) d = "0$d"
        return if (regex.matches(d)) d else null
    }
}
