package ir.niko.sms.ui

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import ir.niko.sms.data.AppDb
import ir.niko.sms.data.Prefs
import ir.niko.sms.data.ScheduledJob
import ir.niko.sms.sms.Queue
import ir.niko.sms.sms.Recipients
import ir.niko.sms.sms.Scheduler
import ir.niko.sms.sms.SendService
import ir.niko.sms.util.Jalali
import ir.niko.sms.util.SimInfo
import ir.niko.sms.util.SmsCalc
import ir.niko.sms.util.Sims
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

class ComposeFragment : Fragment() {
    private lateinit var db: AppDb
    private lateinit var prefs: Prefs
    private lateinit var simGroup: RadioGroup
    private lateinit var simInfo: TextView
    private lateinit var catSpinner: Spinner
    private lateinit var srcTv: TextView
    private lateinit var edit: EditText
    private lateinit var counterTv: TextView
    private lateinit var summaryTv: TextView
    private var sims: List<SimInfo> = emptyList()
    private var resolved: Recipients.Resolved? = null
    private var categories: List<String> = emptyList()
    private var afterPerm: (() -> Unit)? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refreshSims()
        val a = afterPerm
        afterPerm = null
        if (a != null) {
            if (has(Manifest.permission.SEND_SMS) && has(Manifest.permission.READ_PHONE_STATE)) a()
            else requireContext().toast("مجوزهای لازم (پیامک و تلفن) داده نشد.")
        }
    }

    private fun has(p: String) = ContextCompat.checkSelfPermission(requireContext(), p) == PackageManager.PERMISSION_GRANTED

    private fun need(vararg p: String, then: () -> Unit) {
        val missing = p.filter { !has(it) }
        if (missing.isEmpty()) then() else { afterPerm = then; permLauncher.launch(missing.toTypedArray()) }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View {
        val ctx = requireContext()
        db = AppDb.get(ctx)
        prefs = Prefs(ctx)
        val sv = ScrollView(ctx)
        val col = ctx.vbox()
        sv.addView(col)

        col.addView(ctx.tv("سیم‌کارت ارسال‌کننده", 15f, true))
        simGroup = RadioGroup(ctx)
        col.addView(simGroup)
        simInfo = ctx.tv("", 12f, false, C.ORANGE)
        col.addView(simInfo)
        col.addView(ctx.btn("اعطای مجوز تلفن/پیامک", true) {
            permLauncher.launch(arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.SEND_SMS))
        })

        col.add(ctx.tv("مخاطبین هدف", 15f, true), m = 0)
        catSpinner = Spinner(ctx)
        col.addView(catSpinner)
        srcTv = ctx.tv("", 12f, false, C.GRAY)
        col.addView(srcTv)

        col.add(ctx.tv("متن پیامک", 15f, true), m = 0)
        edit = ctx.field("متن پیامک را بنویسید…", prefs.draft, multiline = true)
        edit.doAfterTextChanged { updateCounters() }
        col.addView(edit)
        counterTv = ctx.tv("", 12f, false, C.GRAY)
        col.addView(counterTv)
        summaryTv = ctx.tv("", 13f, true)
        col.addView(summaryTv)

        val r = ctx.hbox()
        r.add(ctx.btn("ذخیره متن", true) { prefs.draft = edit.text.toString(); ctx.toast("متن ذخیره شد.") }, 0, -2, 1f, 2)
        r.add(ctx.btn("زمان‌بندی", true) { scheduleFlow() }, 0, -2, 1f, 2)
        col.addView(r)
        col.addView(ctx.btn("پیش‌نمایش و ارسال") { previewAndSend() })
        col.addView(ctx.tv("ارسال فقط به مخاطبین دارای رضایت و خارج از فهرست سیاه انجام می‌شود. شماره‌ای که همین متن را قبلاً دریافت کرده یا در صف است دوباره اضافه نمی‌شود.", 11f, false, C.GRAY))
        return sv
    }

    override fun onResume() {
        super.onResume()
        refreshSims()
        loadCategories()
    }

    override fun onPause() {
        if (::edit.isInitialized) prefs.draft = edit.text.toString()
        super.onPause()
    }

    private fun refreshSims() {
        val ctx = requireContext()
        sims = Sims.active(ctx)
        simGroup.removeAllViews()
        simInfo.text = if (sims.isEmpty()) "سیم‌کارت فعالی یافت نشد یا مجوز «تلفن» داده نشده است." else ""
        var first: RadioButton? = null
        var stored: RadioButton? = null
        for (s in sims) {
            val rb = RadioButton(ctx)
            rb.id = View.generateViewId()
            rb.tag = s.subId
            rb.text = s.label + if (!s.ready) " (غیرفعال)" else ""
            rb.isEnabled = s.ready
            simGroup.addView(rb)
            if (s.ready) {
                if (first == null) first = rb
                if (s.subId == prefs.simSubId) stored = rb
            }
        }
        (stored ?: first)?.isChecked = true
        simGroup.setOnCheckedChangeListener { g, id ->
            val rb = g.findViewById<RadioButton>(id)
            if (rb != null) prefs.simSubId = rb.tag as Int
        }
    }

    private fun selectedSim(): SimInfo? {
        val id = simGroup.checkedRadioButtonId
        if (id == -1) return null
        val v = simGroup.findViewById<View>(id) ?: return null
        val sid = v.tag as? Int ?: return null
        return sims.firstOrNull { it.subId == sid && it.ready }
    }

    private fun loadCategories() {
        viewLifecycleOwner.lifecycleScope.launch {
            categories = withContext(Dispatchers.IO) { db.contacts().categories() }
            val ctx = requireContext()
            val items = listOf("همه (یا طبق انتخاب در صفحه مخاطبین)") + categories
            catSpinner.onItemSelectedListener = null
            catSpinner.adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, items)
            val idx = categories.indexOf(prefs.category)
            catSpinner.setSelection(if (idx >= 0) idx + 1 else 0)
            catSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    prefs.category = if (pos == 0) "" else categories[pos - 1]
                    recompute()
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
            recompute()
        }
    }

    private fun recompute() {
        viewLifecycleOwner.lifecycleScope.launch {
            resolved = Recipients.resolve(db, prefs.category)
            srcTv.text = "منبع گیرندگان: ${resolved?.source}"
            updateCounters()
        }
    }

    private fun updateCounters() {
        if (!::edit.isInitialized) return
        val i = SmsCalc.calc(edit.text.toString())
        counterTv.text = "کاراکتر: ${i.chars} | بخش‌ها: ${i.parts} | " +
            (if (i.unicode) "یونیکد (فارسی): ۷۰ کاراکتر برای تک‌بخشی، ۶۷ برای هر بخش چندبخشی" else "GSM: ۱۶۰ / ۱۵۳") +
            " | باقی‌مانده در بخش فعلی: ${i.remaining}"
        val r = resolved
        summaryTv.text = if (r == null) "" else
            "گیرندگان مجاز: ${r.ok.size} نفر (حذف‌شده: بدون رضایت ${r.noConsent}، سیاه‌لیست ${r.blacklisted})\nبرآورد تعداد پیامک: ${r.ok.size * i.parts}"
    }

    private fun validate(): Triple<String, SimInfo, Recipients.Resolved>? {
        val ctx = requireContext()
        val text = edit.text.toString().trim()
        val sim = selectedSim()
        val r = resolved
        when {
            text.isEmpty() -> ctx.toast("متن پیامک خالی است.")
            sim == null -> ctx.toast("یک سیم‌کارت فعال انتخاب کنید (و مجوز تلفن را بدهید).")
            r == null || r.ok.isEmpty() -> ctx.toast("گیرنده مجازی وجود ندارد. رضایت مخاطبین را ثبت کنید.")
            else -> return Triple(text, sim, r)
        }
        return null
    }

    private fun previewAndSend() {
        need(Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_STATE) {
            val (text, sim, r) = validate() ?: return@need
            val info = SmsCalc.calc(text)
            val msg = "سیم‌کارت: ${sim.label}\nگیرندگان: ${r.ok.size} نفر\nبرآورد تعداد پیامک: ${r.ok.size * info.parts}\n\nمتن:\n$text\n\n" +
                "با تأیید، گیرندگان به صف اضافه و ارسال آغاز می‌شود. ارسال را می‌توانید از تب «زمان‌بندی» متوقف کنید."
            AlertDialog.Builder(requireContext()).setTitle("پیش‌نمایش و تأیید ارسال").setMessage(msg)
                .setPositiveButton("تأیید و ارسال") { _, _ -> doEnqueue(text, sim, r) }
                .setNegativeButton("انصراف", null).show()
        }
    }

    private fun doEnqueue(text: String, sim: SimInfo, r: Recipients.Resolved) {
        val app = requireContext().applicationContext
        viewLifecycleOwner.lifecycleScope.launch {
            val res = Queue.enqueue(db, text, sim, r.ok)
            if (res.added == 0) {
                app.toast("همه گیرندگان قبلاً این متن را دریافت کرده‌اند یا در صف هستند.")
            } else {
                SendService.start(app)
                app.toast("${res.added} پیامک به صف اضافه شد (تکراری حذف‌شده: ${res.skippedDuplicates}). وضعیت را در تب «زمان‌بندی» ببینید.")
            }
        }
    }

    private fun scheduleFlow() {
        need(Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_STATE) {
            val (text, sim, r) = validate() ?: return@need
            val ctx = requireContext()
            val now = Calendar.getInstance()
            DatePickerDialog(ctx, { _, y, m, d ->
                TimePickerDialog(ctx, { _, hh, mm ->
                    val c = Calendar.getInstance()
                    c.set(y, m, d, hh, mm, 0)
                    c.set(Calendar.MILLISECOND, 0)
                    val at = c.timeInMillis
                    if (at < System.currentTimeMillis() + 30_000) {
                        ctx.toast("زمان باید حداقل ۳۰ ثانیه بعد باشد.")
                    } else {
                        ctx.confirm(
                            "تأیید زمان‌بندی",
                            "ارسال ${r.ok.size} پیامک از ${sim.label}\nدر ${Jalali.format(at).substring(0, 16)} (شمسی)\n\nدر زمان اجرا، رضایت/سیاه‌لیست دوباره بررسی می‌شود. گوشی باید روشن باشد."
                        ) { saveJob(text, sim, r, at) }
                    }
                }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
            }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
        }
    }

    private fun saveJob(text: String, sim: SimInfo, r: Recipients.Resolved, at: Long) {
        val app = requireContext().applicationContext
        viewLifecycleOwner.lifecycleScope.launch {
            val id = withContext(Dispatchers.IO) {
                db.jobs().insert(
                    ScheduledJob(
                        text = text, subId = sim.subId, simLabel = sim.label, triggerAt = at,
                        phones = r.ok.joinToString(",") { it.phone }, recipientCount = r.ok.size,
                        createdAt = System.currentTimeMillis()
                    )
                )
            }
            Scheduler.schedule(app, id, at)
            app.toast("زمان‌بندی ثبت شد. در تب «زمان‌بندی» دیده می‌شود.")
        }
    }
}
