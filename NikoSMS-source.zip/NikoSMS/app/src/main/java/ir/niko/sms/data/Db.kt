package ir.niko.sms.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

object St {
    const val PENDING = "PENDING"
    const val SENDING = "SENDING"
    const val SENT = "SENT"
    const val DELIVERED = "DELIVERED"
    const val FAILED = "FAILED"
    const val CANCELED = "CANCELED"
    fun fa(s: String) = when (s) {
        PENDING -> "در انتظار"
        SENDING -> "در حال ارسال"
        SENT -> "ارسال موفق"
        DELIVERED -> "تحویل شد"
        FAILED -> "ناموفق"
        CANCELED -> "لغو شد"
        else -> s
    }
}

object JobSt {
    const val WAITING = "WAITING"
    const val STARTED = "STARTED"
    const val CANCELED = "CANCELED"
    const val MISSED = "MISSED"
    const val SIM_UNAVAILABLE = "SIM_UNAVAILABLE"
    fun fa(s: String) = when (s) {
        WAITING -> "در انتظار زمان"
        STARTED -> "شروع شد"
        CANCELED -> "لغو شد"
        MISSED -> "از دست رفت (دستگاه در زمان مقرر خاموش بود)"
        SIM_UNAVAILABLE -> "سیم‌کارت در دسترس نبود"
        else -> s
    }
}

@Entity(tableName = "contacts", indices = [Index(value = ["phone"], unique = true)])
data class Contact(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val category: String = "",
    val consent: Boolean = false,
    val consentAt: Long = 0,
    val blacklisted: Boolean = false
)

@Entity(tableName = "sms_log", indices = [Index("batchId"), Index("status"), Index("subId")])
data class SmsLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val batchId: Long,
    val phone: String,
    val name: String,
    val subId: Int,
    val simSlot: Int,
    val simLabel: String,
    val createdAt: Long,
    val text: String,
    val status: String,
    val error: String = "",
    val partsTotal: Int = 1,
    val partsSent: Int = 0,
    val partsDelivered: Int = 0,
    val updatedAt: Long = 0
)

@Entity(tableName = "jobs")
data class ScheduledJob(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val subId: Int,
    val simLabel: String,
    val triggerAt: Long,
    val phones: String,
    val recipientCount: Int,
    val state: String = JobSt.WAITING,
    val createdAt: Long
)

data class SimStat(val subId: Int, val status: String, val cnt: Int)

@Dao
interface ContactDao {
    @Query("SELECT * FROM contacts") suspend fun all(): List<Contact>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertAll(l: List<Contact>): List<Long>
    @Query("UPDATE contacts SET name=:name, category=:cat, consent=:consent, consentAt=:at, blacklisted=:bl WHERE phone=:phone")
    suspend fun updateByPhone(phone: String, name: String, cat: String, consent: Boolean, at: Long, bl: Boolean)
    @Query("UPDATE contacts SET consent=:v, consentAt=:at WHERE id IN (:ids)") suspend fun setConsent(ids: List<Long>, v: Boolean, at: Long)
    @Query("UPDATE contacts SET blacklisted=:v WHERE id IN (:ids)") suspend fun setBlacklist(ids: List<Long>, v: Boolean)
    @Query("UPDATE contacts SET category=:c WHERE id IN (:ids)") suspend fun setCategory(ids: List<Long>, c: String)
    @Query("DELETE FROM contacts WHERE id IN (:ids)") suspend fun delete(ids: List<Long>)
    @Query("SELECT DISTINCT category FROM contacts WHERE category != '' ORDER BY category") suspend fun categories(): List<String>
}

@Dao
interface SmsLogDao {
    @Insert suspend fun insertAll(l: List<SmsLog>): List<Long>
    @Update suspend fun update(l: SmsLog)
    @Query("SELECT * FROM sms_log WHERE id=:id") suspend fun get(id: Long): SmsLog?
    @Query("SELECT * FROM sms_log WHERE status='PENDING' ORDER BY id LIMIT 1") suspend fun nextPending(): SmsLog?
    @Query("UPDATE sms_log SET status=:s, error=:e, updatedAt=:t WHERE id=:id") suspend fun mark(id: Long, s: String, e: String, t: Long)
    @Query("UPDATE sms_log SET partsTotal=:n, updatedAt=:t WHERE id=:id") suspend fun setParts(id: Long, n: Int, t: Long)
    @Query("UPDATE sms_log SET status='CANCELED', error=:e, updatedAt=:t WHERE status='PENDING'") suspend fun cancelPending(e: String, t: Long)
    @Query("UPDATE sms_log SET status='FAILED', error='وقفه در ارسال؛ وضعیت نامشخص', updatedAt=:now WHERE status='SENDING' AND updatedAt<:before")
    suspend fun recoverStuck(now: Long, before: Long)
    @Query("SELECT DISTINCT phone FROM sms_log WHERE text=:text AND status IN ('PENDING','SENDING','SENT','DELIVERED')")
    suspend fun phonesAlready(text: String): List<String>
    @Query("SELECT * FROM sms_log WHERE (:slot=-1 OR simSlot=:slot) ORDER BY id DESC LIMIT :limit")
    fun observe(slot: Int, limit: Int): Flow<List<SmsLog>>
    @Query("SELECT * FROM sms_log WHERE (:slot=-1 OR simSlot=:slot) ORDER BY id")
    suspend fun export(slot: Int): List<SmsLog>
    @Query("SELECT COUNT(*) FROM sms_log WHERE status=:s") fun observeCount(s: String): Flow<Int>
    @Query("SELECT COUNT(*) FROM sms_log WHERE status=:s") suspend fun count(s: String): Int
    @Query("SELECT subId AS subId, status AS status, COUNT(*) AS cnt FROM sms_log GROUP BY subId, status")
    fun observeSimStats(): Flow<List<SimStat>>
    @Query("DELETE FROM sms_log") suspend fun deleteAll()
}

@Dao
interface JobDao {
    @Insert suspend fun insert(j: ScheduledJob): Long
    @Query("SELECT * FROM jobs WHERE id=:id") suspend fun get(id: Long): ScheduledJob?
    @Query("SELECT * FROM jobs WHERE state='WAITING'") suspend fun waiting(): List<ScheduledJob>
    @Query("SELECT * FROM jobs ORDER BY triggerAt DESC") fun observe(): Flow<List<ScheduledJob>>
    @Query("UPDATE jobs SET state=:s WHERE id=:id") suspend fun setState(id: Long, s: String)
}

@Database(entities = [Contact::class, SmsLog::class, ScheduledJob::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun contacts(): ContactDao
    abstract fun logs(): SmsLogDao
    abstract fun jobs(): JobDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "niko.db").build().also { inst = it }
        }
    }
}
