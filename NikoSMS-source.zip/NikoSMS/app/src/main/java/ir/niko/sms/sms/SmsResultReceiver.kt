package ir.niko.sms.sms

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager
import android.telephony.SmsMessage
import ir.niko.sms.data.AppDb
import ir.niko.sms.data.St
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class SmsResultReceiver : BroadcastReceiver() {
    companion object {
        private val mutex = Mutex()
        // کدهای محدودیت/ممنوعیت: 5=LIMIT_EXCEEDED ، 6/7=SHORT_CODE_NOT_ALLOWED/NEVER_ALLOWED
        private val LIMIT_CODES = setOf(5, 6, 7)

        fun errorText(code: Int, net: Int): String {
            val base = when (code) {
                SmsManager.RESULT_ERROR_GENERIC_FAILURE -> "خطای عمومی ارسال"
                SmsManager.RESULT_ERROR_NO_SERVICE -> "عدم آنتن‌دهی / بدون سرویس"
                SmsManager.RESULT_ERROR_NULL_PDU -> "PDU نامعتبر"
                SmsManager.RESULT_ERROR_RADIO_OFF -> "رادیو خاموش (حالت پرواز؟)"
                5 -> "عبور از سقف مجاز ارسال"
                6 -> "ارسال به شماره کوتاه مجاز نیست"
                7 -> "ارسال به شماره کوتاه همیشه ممنوع است"
                else -> "کد خطا $code"
            }
            return if (net >= 0) "$base (کد شبکه $net)" else base
        }
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1L)
        if (id < 0) return
        val action = intent.action ?: return
        val code = resultCode
        val net = intent.getIntExtra("errorCode", -1)
        val pdu = intent.getByteArrayExtra("pdu")
        val fmt = intent.getStringExtra("format")
        val pending = goAsync()
        val app = ctx.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                mutex.withLock {
                    val dao = AppDb.get(app).logs()
                    val log = dao.get(id) ?: return@withLock
                    val now = System.currentTimeMillis()
                    if (action == SendService.ACTION_SENT) {
                        if (code == Activity.RESULT_OK) {
                            val ps = log.partsSent + 1
                            val st = if (log.status == St.SENDING && ps >= log.partsTotal) St.SENT else log.status
                            dao.update(log.copy(partsSent = ps, status = st, updatedAt = now))
                            SendState.noteSuccess()
                        } else {
                            val err = errorText(code, net)
                            if (log.status != St.FAILED) dao.update(log.copy(status = St.FAILED, error = err, updatedAt = now))
                            SendState.noteFailure()
                            if (code in LIMIT_CODES) SendState.autoStop("خطای محدودیت ارسال: $err")
                        }
                    } else if (action == SendService.ACTION_DELIVERED) {
                        val st = if (pdu != null) {
                            try { SmsMessage.createFromPdu(pdu, fmt).status } catch (e: Exception) { 0 }
                        } else 0
                        if (st == 0) {
                            val pd = log.partsDelivered + 1
                            val ns = if (pd >= log.partsTotal && (log.status == St.SENT || log.status == St.SENDING)) St.DELIVERED else log.status
                            dao.update(log.copy(partsDelivered = pd, status = ns, updatedAt = now))
                        } else if (st >= 64) {
                            dao.update(log.copy(status = St.FAILED, error = "گزارش تحویل: ناموفق (کد $st)", updatedAt = now))
                        }
                    }
                }
            } finally {
                pending.finish()
            }
        }
    }
}
