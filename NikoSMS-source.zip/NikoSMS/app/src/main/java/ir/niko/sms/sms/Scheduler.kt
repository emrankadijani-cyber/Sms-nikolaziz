package ir.niko.sms.sms

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import ir.niko.sms.data.AppDb
import ir.niko.sms.data.JobSt
import ir.niko.sms.util.Sims
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object Scheduler {
    private fun pi(ctx: Context, id: Long) = PendingIntent.getBroadcast(
        ctx, id.toInt(),
        Intent(ctx, ScheduleReceiver::class.java).setData(Uri.parse("niko://job/$id")).putExtra("jobId", id),
        PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun schedule(ctx: Context, id: Long, at: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val exactOk = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        if (exactOk) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx, id))
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx, id))
    }

    fun cancel(ctx: Context, id: Long) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pi(ctx, id))
    }

    suspend fun fire(ctx: Context, id: Long) {
        val db = AppDb.get(ctx)
        val job = db.jobs().get(id) ?: return
        if (job.state != JobSt.WAITING) return
        val sim = Sims.active(ctx).firstOrNull { it.subId == job.subId && it.ready }
        if (sim == null) { db.jobs().setState(id, JobSt.SIM_UNAVAILABLE); return }
        db.jobs().setState(id, JobSt.STARTED)
        val phones = job.phones.split(',').toHashSet()
        // رضایت/سیاه‌لیست در لحظه ارسال دوباره بررسی می‌شود
        val recipients = db.contacts().all().filter { it.phone in phones && it.consent && !it.blacklisted }
        val r = Queue.enqueue(db, job.text, sim, recipients)
        if (r.added > 0) SendService.start(ctx)
    }

    suspend fun rescheduleAll(ctx: Context) {
        val db = AppDb.get(ctx)
        val now = System.currentTimeMillis()
        for (j in db.jobs().waiting()) {
            if (j.triggerAt < now - 2 * 60_000L) db.jobs().setState(j.id, JobSt.MISSED)
            else schedule(ctx, j.id, maxOf(j.triggerAt, now + 2000))
        }
    }
}

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("jobId", -1L)
        if (id < 0) return
        val pending = goAsync()
        val app = ctx.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try { Scheduler.fire(app, id) } finally { pending.finish() }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        val app = ctx.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try { Scheduler.rescheduleAll(app) } finally { pending.finish() }
        }
    }
}
