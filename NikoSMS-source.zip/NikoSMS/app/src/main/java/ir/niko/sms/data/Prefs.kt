package ir.niko.sms.data

import android.content.Context

class Prefs(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("niko_prefs", Context.MODE_PRIVATE)
    var delaySec: Int get() = p.getInt("delaySec", 3); set(v) = p.edit().putInt("delaySec", v).apply()
    var batchSize: Int get() = p.getInt("batchSize", 20); set(v) = p.edit().putInt("batchSize", v).apply()
    var batchPauseSec: Int get() = p.getInt("batchPauseSec", 60); set(v) = p.edit().putInt("batchPauseSec", v).apply()
    var requestDelivery: Boolean get() = p.getBoolean("delivery", true); set(v) = p.edit().putBoolean("delivery", v).apply()
    var draft: String get() = p.getString("draft", "") ?: ""; set(v) = p.edit().putString("draft", v).apply()
    var simSubId: Int get() = p.getInt("simSubId", -1); set(v) = p.edit().putInt("simSubId", v).apply()
    var category: String get() = p.getString("category", "") ?: ""; set(v) = p.edit().putString("category", v).apply()
    fun clear() = p.edit().clear().apply()
}
