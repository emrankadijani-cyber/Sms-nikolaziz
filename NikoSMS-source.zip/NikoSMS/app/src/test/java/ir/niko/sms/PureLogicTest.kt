package ir.niko.sms

import ir.niko.sms.util.Csv
import ir.niko.sms.util.Jalali
import ir.niko.sms.util.PhoneNormalizer
import org.junit.Assert.*
import org.junit.Test

class PureLogicTest {
    @Test fun normalizeForms() {
        val e = "09123456789"
        assertEquals(e, PhoneNormalizer.normalize("09123456789"))
        assertEquals(e, PhoneNormalizer.normalize("+98 912 345 6789"))
        assertEquals(e, PhoneNormalizer.normalize("989123456789"))
        assertEquals(e, PhoneNormalizer.normalize("00989123456789"))
        assertEquals(e, PhoneNormalizer.normalize("9123456789"))
        assertEquals(e, PhoneNormalizer.normalize("۰۹۱۲۳۴۵۶۷۸۹"))
    }
    @Test fun normalizeRejects() {
        assertNull(PhoneNormalizer.normalize("02112345678"))
        assertNull(PhoneNormalizer.normalize("0912345"))
        assertNull(PhoneNormalizer.normalize(""))
        assertNull(PhoneNormalizer.normalize(null))
    }
    @Test fun csvParse() {
        assertEquals(listOf("a", "b,c", "d\"e"), Csv.parseLine("a,\"b,c\",\"d\"\"e\""))
        assertEquals(listOf("x", "y"), Csv.parseLine("x;y", ';'))
    }
    @Test fun csvEscInjection() {
        assertEquals("'=1+1", Csv.esc("=1+1"))
    }
    @Test fun jalali() {
        assertArrayEquals(intArrayOf(1403, 1, 1), Jalali.fromGregorian(2024, 3, 20))
        assertArrayEquals(intArrayOf(1405, 8, 10), Jalali.fromGregorian(2026, 11, 1))
    }
}
